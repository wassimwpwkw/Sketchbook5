package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var bitmap: Bitmap? = null
    private var loaded: Tracer.Loaded? = null
    private var threshold = 55
    private var detail = 40
    private var fillGap = 8
    private var colors = 12
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView
    private lateinit var clLabel: TextView

    private fun label() = TextView(this).apply { gravity = Gravity.CENTER }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density

        val info = TextView(this).apply {
            text = "1) فعّل الخدمة\n2) اختر الصورة وراجع المعاينة\n" +
                "3) في Sketchbook ضع الصورة نفسها كطبقة مرجعية على الكانفس\n" +
                "4) من الشريط العائم: ⛶ ثم اضغط زاويتي الصورة المرجعية\n" +
                "5) ⧉ لتعليم زر الطبقات (مرة واحدة)\n6) اضغط ▶ ابدأ وانتظر"
            textSize = 15f
            gravity = Gravity.CENTER
        }
        val btnAcc = Button(this).apply { text = "تفعيل الخدمة" }
        val btnPick = Button(this).apply { text = "اختيار صورة" }

        thLabel = label().apply { text = "سواد الخطوط: $threshold" }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        dtLabel = label().apply { text = "تفاصيل الخطوط: $detail" }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        clLabel = label().apply { text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        val seekCl = SeekBar(this).apply { max = 24; progress = colors }
        fgLabel = label().apply { text = "تباعد التلوين (حسب سمك فرشاتك): $fillGap" }
        val seekFg = SeekBar(this).apply { max = 27; progress = fillGap - 3 }

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        status = label().apply { text = "لم تُختر صورة بعد" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (24 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
            addView(info)
            addView(btnAcc)
            addView(btnPick)
            addView(thLabel); addView(seekTh)
            addView(dtLabel); addView(seekDt)
            addView(clLabel); addView(seekCl)
            addView(fgLabel); addView(seekFg)
            addView(preview, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (420 * d).toInt()))
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "اختر صورة"), 1)
        }

        fun bind(seek: SeekBar, onChange: (Int) -> Unit) {
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { process() }
            })
        }
        bind(seekTh) { p -> threshold = 20 + p; thLabel.text = "سواد الخطوط: $threshold" }
        bind(seekDt) { p -> detail = p; dtLabel.text = "تفاصيل الخطوط: $detail" }
        bind(seekCl) { p -> colors = p; clLabel.text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        bind(seekFg) { p -> fillGap = 3 + p; fgLabel.text = "تباعد التلوين (حسب سمك فرشاتك): $fillGap" }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "جاري تحميل الصورة..."
            thread {
                val ld = Tracer.load(this, uri, 1100)
                runOnUiThread {
                    if (ld == null) {
                        status.text = "تعذّر فتح الصورة"
                    } else {
                        bitmap = ld.bmp
                        loaded = ld
                        process()
                    }
                }
            }
        }
    }

    private fun process() {
        val bmp = bitmap ?: return
        val ld = loaded ?: return
        status.text = "جاري تحليل الصورة..."
        val t = threshold
        val dt = detail
        val fg = fillGap
        val cl = colors
        thread {
            try {
                val r = Tracer.process(bmp, t, dt, fg, cl)
                runOnUiThread {
                    Shared.phases = r.phases
                    Shared.imgW = r.w
                    Shared.imgH = r.h
                    Shared.fx0 = ld.fx0
                    Shared.fy0 = ld.fy0
                    Shared.fw = ld.fw
                    Shared.fh = ld.fh
                    Shared.aspect = ld.aspect
                    preview.setImageBitmap(r.preview)
                    var total = 0
                    for (p in r.phases) total += p.strokes.size
                    status.text = "جاهز: ${r.phases.size} مرحلة، $total خط. افتح Sketchbook الآن."
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "خطأ في التحليل: ${e.message}" }
            }
        }
    }
}
