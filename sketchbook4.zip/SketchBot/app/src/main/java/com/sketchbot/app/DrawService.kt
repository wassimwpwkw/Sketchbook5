package com.sketchbot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class DrawService : AccessibilityService() {

    companion object { var instance: DrawService? = null }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private var wm: WindowManager? = null
    private var panel: View? = null
    private var calib: View? = null
    private var card: View? = null
    private var rect: RectF? = null
    private var layerP0: PointF? = null
    private var layerP1: PointF? = null
    private var auto = true

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        loadPrefs()
        showPanel()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun removeOverlay(v: View?) {
        if (v == null) return
        try { wm?.removeView(v) } catch (_: Exception) {}
    }

    private fun cleanup() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(panel)
        removeOverlay(calib)
        removeOverlay(card)
        panel = null
        calib = null
        card = null
        instance = null
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
    )

    // ---------- الحفظ ----------
    private fun prefs() = getSharedPreferences("sb", Context.MODE_PRIVATE)

    private fun loadPrefs() {
        val p = prefs()
        if (p.contains("l")) {
            rect = RectF(p.getFloat("l", 0f), p.getFloat("t", 0f), p.getFloat("r", 0f), p.getFloat("b", 0f))
        }
        if (p.contains("lx0")) {
            layerP0 = PointF(p.getFloat("lx0", 0f), p.getFloat("ly0", 0f))
            layerP1 = PointF(p.getFloat("lx1", 0f), p.getFloat("ly1", 0f))
        }
        auto = p.getBoolean("auto", true)
    }

    private fun saveRect(r: RectF) {
        prefs().edit()
            .putFloat("l", r.left).putFloat("t", r.top).putFloat("r", r.right).putFloat("b", r.bottom).apply()
    }

    private fun saveLayers(a: PointF, b: PointF) {
        prefs().edit()
            .putFloat("lx0", a.x).putFloat("ly0", a.y).putFloat("lx1", b.x).putFloat("ly1", b.y).apply()
    }

    private fun autoText() = if (auto) "🎨 تلقائي ✓" else "🎨 تلقائي ✗"

    // ---------- الشريط العائم ----------
    private fun showPanel() {
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun tv(t: String) = TextView(this@DrawService).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding((10 * d).toInt(), (9 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
        }
        val handle = tv("☰")
        val bStart = tv("▶ ابدأ")
        val bStop = tv("■ إيقاف")
        val bCal = tv("⛶ الصورة")
        val bLay = tv("⧉ طبقات")
        val bAuto = tv(autoText())
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(handle); addView(bStart); addView(bStop)
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(bCal); addView(bLay); addView(bAuto)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xDD222222.toInt())
            addView(row1); addView(row2)
        }
        val lp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (240 * d).toInt()
        }

        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt()
                    lp.y = sy + (e.rawY - dy).toInt()
                    try { w.updateViewLayout(root, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        bStart.setOnClickListener { startDrawing() }
        bStop.setOnClickListener { stop(); toast("تم الإيقاف") }
        bCal.setOnClickListener { calibrate() }
        bLay.setOnClickListener { teachLayers() }
        bAuto.setOnClickListener {
            auto = !auto
            prefs().edit().putBoolean("auto", auto).apply()
            bAuto.text = autoText()
            toast(if (auto) "اختيار الألوان تلقائي" else "اختيار الألوان يدوي (بطاقة لكل لون)")
        }

        w.addView(root, lp)
        panel = root
    }

    // ---------- بطاقة اختيار اللون (الوضع اليدوي) ----------
    private fun showColorCard(ph: Phase, idx: Int, total: Int, onContinue: () -> Unit) {
        val w = wm ?: return
        removeOverlay(card)
        val d = resources.displayMetrics.density
        val hex = String.format("#%06X", 0xFFFFFF and ph.color)

        val swatch = View(this).apply { setBackgroundColor(ph.color) }
        val title = TextView(this).apply {
            text = "المرحلة $idx/$total: ${ph.label}\n$hex"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding((10 * d).toInt(), 0, 0, 0)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(swatch, LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()))
            addView(title)
        }
        val btn = TextView(this).apply {
            text = "▶ متابعة بعد اختيار اللون"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF2E7D32.toInt())
            setPadding(0, (10 * d).toInt(), 0, (10 * d).toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE222222.toInt())
            setPadding((12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt(), (12 * d).toInt())
            addView(top)
            addView(btn)
        }
        val lp = overlayParams(
            (320 * d).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (40 * d).toInt()
        }
        btn.setOnClickListener {
            removeOverlay(root)
            card = null
            onContinue()
        }
        w.addView(root, lp)
        card = root
    }

    // ---------- شاشات التعليم ----------
    private class CalibView(ctx: Context) : View(ctx) {
        var a: PointF? = null
        var b: PointF? = null
        private val p = Paint().apply {
            color = 0xFFFF4081.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x33000000)
            val pa = a
            val pb = b
            if (pa != null) c.drawCircle(pa.x, pa.y, 20f, p)
            if (pb != null) c.drawCircle(pb.x, pb.y, 20f, p)
            if (pa != null && pb != null) c.drawRect(
                Math.min(pa.x, pb.x), Math.min(pa.y, pb.y),
                Math.max(pa.x, pb.x), Math.max(pa.y, pb.y), p
            )
        }
    }

    private class TapView(ctx: Context) : View(ctx) {
        val pts = ArrayList<PointF>()
        private val p = Paint().apply {
            color = 0xFF40C4FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        override fun onDraw(c: Canvas) {
            c.drawColor(0x22000000)
            for (pt in pts) c.drawCircle(pt.x, pt.y, 24f, p)
        }
    }

    private fun fullScreenParams() = overlayParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    )

    // زاويتا الصورة المرجعية داخل Sketchbook
    private fun calibrate() {
        val w = wm ?: return
        if (calib != null) return
        val v = CalibView(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (v.a == null) {
                    v.a = PointF(e.rawX, e.rawY)
                    v.invalidate()
                    toast("الآن اضغط الزاوية السفلية اليمنى للصورة")
                } else if (v.b == null) {
                    val a = v.a!!
                    v.b = PointF(e.rawX, e.rawY)
                    val r = RectF(
                        Math.min(a.x, e.rawX), Math.min(a.y, e.rawY),
                        Math.max(a.x, e.rawX), Math.max(a.y, e.rawY)
                    )
                    v.invalidate()
                    if (r.width() < 150f || r.height() < 150f) {
                        toast("المساحة صغيرة جداً، أعد المحاولة")
                    } else {
                        rect = r
                        saveRect(r)
                        toast("تم حفظ مكان الصورة")
                    }
                    handler.postDelayed({
                        removeOverlay(v)
                        calib = null
                    }, 1200)
                }
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        toast("اضغط الزاوية العليا اليسرى للصورة المرجعية")
    }

    // تعليم زر الطبقات وزر إضافة طبقة (لوحة الطبقات مفتوحة)
    private fun teachLayers() {
        val w = wm ?: return
        if (calib != null) return
        val v = TapView(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                v.pts.add(PointF(e.rawX, e.rawY))
                v.invalidate()
                if (v.pts.size == 1) {
                    toast("الآن اضغط زر ⊕ إضافة طبقة جديدة")
                } else if (v.pts.size == 2) {
                    layerP0 = v.pts[0]
                    layerP1 = v.pts[1]
                    saveLayers(v.pts[0], v.pts[1])
                    toast("تم حفظ الطبقات. أغلق لوحة الطبقات الآن")
                    handler.postDelayed({
                        removeOverlay(v)
                        calib = null
                    }, 1000)
                }
            }
            true
        }
        w.addView(v, fullScreenParams())
        calib = v
        toast("لوحة الطبقات مفتوحة؟ اضغط أيقونة الطبقات")
    }

    // ---------- اللمسات ----------
    private fun tapAt(x: Float, y: Float, duration: Long, onDone: () -> Unit) {
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                handler.postDelayed({ if (running) onDone() }, 700)
            }
            override fun onCancelled(d: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }

    private fun newLayer(onDone: () -> Unit) {
        val a = layerP0
        val b = layerP1
        if (a == null || b == null) { onDone(); return }
        tapAt(a.x, a.y, 60) {
            tapAt(b.x, b.y, 60) {
                tapAt(a.x, a.y, 60) { onDone() }
            }
        }
    }

    // ---------- الرسم ----------
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removeOverlay(card)
        card = null
    }

    private fun startDrawing() {
        val r = rect
        val src = Shared.phases
        if (src.isEmpty()) { toast("اختر صورة من التطبيق أولاً"); return }
        if (r == null) { toast("حدّد مكان الصورة (⛶) أولاً"); return }
        if (running) return

        val asp = Shared.aspect
        val dispW = Math.min(r.width(), r.height() * asp)
        val dispH = dispW / asp
        val left = r.left + (r.width() - dispW) / 2f
        val top = r.top + (r.height() - dispH) / 2f
        val iw = Shared.imgW.toFloat()
        val ih = Shared.imgH.toFloat()
        fun mx(px: Float) = left + (Shared.fx0 + px / iw * Shared.fw) * dispW
        fun my(py: Float) = top + (Shared.fy0 + py / ih * Shared.fh) * dispH

        val mapped = src.map { ph ->
            val ms = ph.strokes.map { st -> st.map { PointF(mx(it.x), my(it.y)) } }
            Phase(
                ph.color, ph.label, order(ms), ph.fast,
                if (ph.pickX >= 0f) mx(ph.pickX) else -1f,
                if (ph.pickY >= 0f) my(ph.pickY) else -1f
            )
        }
        running = true
        toast("جاري التحضير...")
        handler.postDelayed({ runPhase(mapped, 0) }, 1200)
    }

    private fun runPhase(ps: List<Phase>, idx: Int) {
        if (!running) return
        if (idx >= ps.size) {
            running = false
            toast("انتهى الرسم 🎉")
            return
        }
        val ph = ps[idx]
        val go = {
            if (running) drawNext(ph.strokes, 0, ph.fast) { runPhase(ps, idx + 1) }
        }
        if (ps.size == 1) {
            go()
            return
        }
        if (auto) {
            val afterPick = { newLayer { go() } }
            if (ph.pickX >= 0f) tapAt(ph.pickX, ph.pickY, 900) { afterPick() } else afterPick()
        } else {
            showColorCard(ph, idx + 1, ps.size) { handler.postDelayed({ go() }, 700) }
        }
    }

    private fun order(list: List<List<PointF>>): List<List<PointF>> {
        if (list.isEmpty()) return list
        val rem = list.toMutableList()
        val out = ArrayList<List<PointF>>()
        var cx = 0f
        var cy = 0f
        while (rem.isNotEmpty()) {
            var best = -1
            var bd = Float.MAX_VALUE
            var rev = false
            for (i in rem.indices) {
                val a = rem[i].first()
                val b = rem[i].last()
                val da = (a.x - cx) * (a.x - cx) + (a.y - cy) * (a.y - cy)
                val db = (b.x - cx) * (b.x - cx) + (b.y - cy) * (b.y - cy)
                if (da < bd) { bd = da; best = i; rev = false }
                if (db < bd) { bd = db; best = i; rev = true }
            }
            val st = rem.removeAt(best)
            val o = if (rev) st.reversed() else st
            out.add(o)
            cx = o.last().x
            cy = o.last().y
        }
        return out
    }

    private fun drawNext(strokes: List<List<PointF>>, i: Int, fast: Boolean, onDone: () -> Unit) {
        if (!running) return
        if (i >= strokes.size) { onDone(); return }
        val pts = strokes[i].map {
            PointF(it.x + Random.nextFloat() * 3f - 1.5f, it.y + Random.nextFloat() * 3f - 1.5f)
        }
        if (pts.size < 2) { drawNext(strokes, i + 1, fast, onDone); return }

        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        var len = 0f
        for (k in 1 until pts.size) {
            val dx = pts[k].x - pts[k - 1].x
            val dy = pts[k].y - pts[k - 1].y
            len += Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        for (k in 1 until pts.size - 1) {
            path.quadTo(pts[k].x, pts[k].y, (pts[k].x + pts[k + 1].x) / 2f, (pts[k].y + pts[k + 1].y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)

        val speed = if (fast) 1.2f + Random.nextFloat() * 1.6f else 0.4f + Random.nextFloat() * 0.8f
        val duration = (len / speed).toLong().coerceIn(120L, 15000L)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                val pause = if (fast) {
                    if (Random.nextInt(40) == 0) Random.nextLong(800, 2000) else Random.nextLong(30, 150)
                } else {
                    if (Random.nextInt(12) == 0) Random.nextLong(1500, 3500) else Random.nextLong(100, 500)
                }
                handler.postDelayed({ drawNext(strokes, i + 1, fast, onDone) }, pause)
            }
            override fun onCancelled(g: GestureDescription?) { running = false }
        }, null)
        if (!ok) running = false
    }
}
